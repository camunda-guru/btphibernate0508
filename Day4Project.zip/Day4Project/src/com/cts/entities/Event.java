package com.cts.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="CTSEvent")
public class Event {
   @Id
   @GeneratedValue(strategy=GenerationType.IDENTITY)
   @Column(name="Event_Id")
	private int eventId;
   @Column(name="Event_Name")
	private String eventName;
   @Temporal(TemporalType.DATE)
   @Column(name="Event_Date")
	private Date eventDate;
   @Column(name="Tickets_Available")
	private int ticketsAvailable;
   @OneToOne
  @JoinColumn(name="Location_Id")
	private Location location;
public int getEventId() {
	return eventId;
}
public void setEventId(int eventId) {
	this.eventId = eventId;
}
public String getEventName() {
	return eventName;
}
public void setEventName(String eventName) {
	this.eventName = eventName;
}
public Date getEventDate() {
	return eventDate;
}
public void setEventDate(Date eventDate) {
	this.eventDate = eventDate;
}
public int getTicketsAvailable() {
	return ticketsAvailable;
}
public void setTicketsAvailable(int ticketsAvailable) {
	this.ticketsAvailable = ticketsAvailable;
}
public Location getLocation() {
	return location;
}
public void setLocation(Location location) {
	this.location = location;
}
}
