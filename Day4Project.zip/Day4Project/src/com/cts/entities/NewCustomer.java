package com.cts.entities;

import javax.persistence.Entity;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

@Entity
@Table(name="CTS_NewCustomer")
public class NewCustomer  extends Customer{

}
