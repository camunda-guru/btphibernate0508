package com.cts.util;

import com.cts.dao.BookingDao;
import com.cts.entities.Location;

public class TestApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	BookingDao	dao=new BookingDao();
	System.out.println(dao.TestSecondLevelCache());
	}

}
